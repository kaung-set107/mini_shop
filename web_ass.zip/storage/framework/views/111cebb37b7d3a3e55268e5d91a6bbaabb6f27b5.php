 <?php $__env->startSection('content'); ?>
<?php $__env->startSection('item-active','active'); ?>
<a href="<?php echo e(route('items.create')); ?>">Item List</a>
<a
    href="<?php echo e(route('items.create')); ?>"
    class="btn btn-sm add rounded item-btn mt-3"
    >+&nbsp;Add Items</a
>
<div class="container">
    <table class="table table-border">
        <thead>
            <tr>
                <th>Action</th>
                <th>No</th>
                <th>Item</th>
                <th>Category</th>
                <th>Description</th>
                <th>Price</th>
                <th>Owner</th>
                <th>Public</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a
                        href="<?php echo e(route('items.edit',$i->id)); ?>"
                        class="badge badge-success"
                        ><i class="bi bi-pencil"></i
                    ></a>

                    

                <form
                action="<?php echo e(route('items.destroy',$i->id)); ?>"
                method="get"
                id="delete"
                class="d-inline"
            >
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                
                    <button
                    type="submit"
                    onclick="return confirm('Do you want to delete this Category?')"
                    class="badge badge-danger"
                >
                    <i class="bi bi-trash"></i>
                </button>
                </td>

                <td><?php echo e($i->id); ?></td>
                <td><?php echo e($i->name); ?></td>
                <td><?php echo e($i->category->name); ?></td>
                <td><?php echo e($i->description); ?></td>
                <td><?php echo e($i->price); ?></td>
                <td><?php echo e($i->ownername); ?></td>
                <td>
                    <?php if($i->status == 'public'): ?>
                    <label class="switch">
                        <input type="checkbox" checked />
                        <span class="slider round"></span>
                    </label>
                    <?php else: ?>

                    <label class="switch">
                        <input type="checkbox" />
                        <span class="slider round"></span>
                    </label>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="mt-3">
    <?php echo e($item->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Web_Assignment/web_ass/resources/views/backend/item.blade.php ENDPATH**/ ?>