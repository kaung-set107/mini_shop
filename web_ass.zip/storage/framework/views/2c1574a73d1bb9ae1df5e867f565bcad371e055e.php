 <?php $__env->startSection('content'); ?>
<?php $__env->startSection('cat-active','active'); ?>
<a href="<?php echo e(route('category.create')); ?>">Categories</a>
<a
    href="<?php echo e(route('category.create')); ?>"
    class="btn btn-sm add rounded item-btn"
    >+&nbsp;Add Categories</a
>
<div class="container">
    <table class="table table-border">
        <thead>
            <tr>
                <th>Action</th>
                <th>No</th>
                <th>Category</th>
                <th>Public</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a
                href="<?php echo e(route('category.edit',$c->id)); ?>"
                class="badge badge-success"
                ><i class="bi bi-pencil"></i
                    ></a
            >

            

            <form
                action="<?php echo e(route('category.destroy',$c->id)); ?>"
                method="POST"
                id="delete"
                class="d-inline"
            >
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <!-- <a
                    href="#"
                    onclick="confirm('Delete?') ? document.getElementById('delete').submit() :false "
                    class="badge badge-danger"
                    >Delete</a
                > -->
                <button
                    type="submit"
                    onclick="return confirm('Do you want to delete this Category?')"
                    class="badge badge-danger"
                >
                    <i class="bi bi-trash"></i>
                </button></td>
                <td><?php echo e($c->id); ?></td>
                <td><?php echo e($c->name); ?></td>
                <td>
                    <?php if($c->status == 'public'): ?>
                            <label class="switch">
                            <input type="checkbox" checked>
                            <span class="slider round"></span>
                            </label>
                    <?php else: ?>
                    
                    <label class="switch">
  <input type="checkbox">
  <span class="slider round"></span>
</label>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="mt-3">
    <?php echo e($category->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Web_Assignment/web_ass/resources/views/backend/category.blade.php ENDPATH**/ ?>