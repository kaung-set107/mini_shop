 <?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="d-flex link">
        <a href="<?php echo e(url('/')); ?>" class="text-muted mb-0 hover-cursor">
            &nbsp;Home&nbsp; </a
        ><i class="bi bi-chevron-right"></i>
        <p class="text-primary mb-0 hover-cursor">Fashion</p>
    </div>
    <div class="row">
        <div class="col-md-3 mt-5">
            <div class="row">
                <div class="col-md-6">
                    <a href="">Filter By</a>
                </div>
                <div class="col-md-6">
                    <a href="" class="text-danger">Clear Filter</a>
                </div>
            </div>
            <div class="row mt-5 input-color">
                <form action="<?php echo e(url('/filter')); ?>" method="get">
                    <p>Sorting</p>
                    <div class="form-group d-flex justy-content-between">
                          
                        <input
                            type="radio"
                            id="latest"
                            name="sort"
                            value="Latest"
                        />
                          <label for="latest">Latest</label>&nbsp;&nbsp;&nbsp;
                        <input
                            type="radio"
                            id="popular"
                            name="sort"
                            value="Popular"
                        />
                          <label for="popular">Popular</label>
                    </div>
                    <div class="form-group">
                        <p>Item Name</p>
                        <input
                            type="text"
                            name="name"
                            id=""
                            class="form-control"
                            placeholder="Input Name"
                        />
                    </div>
                    <p>Price Range</p>
                    <div class="form-group d-flex justy-content-between">
                         
                        <input
                            type="number"
                            name="min"
                            min="1"
                            class="form-control"
                            placeholder="Min"
                        />
                        &nbsp;
                        <input
                            type="number"
                            name="max"
                            max="100000000"
                            class="form-control"
                            placeholder="Max"
                        />
                    </div>
                    <div class="form-group">
                        <p>Select Category</p>
                        <select
                            name="category_id"
                            id=""
                            class="form-control mt-1"
                        >
                            <option value="">Choose One</option>
                            <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <p>Select Item Condition</p>
                        <select
                            name="condition_id"
                            id=""
                            class="form-control mt-1"
                        >
                            <option value="">Choose One</option>
                            <?php $__currentLoopData = $item_con; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>">
                                <?php echo e($c->condition); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <p>Select Item Type</p>
                        <select name="type_id" id="" class="form-control mt-1">
                            <option value="">Choose One</option>
                            <?php $__currentLoopData = $item_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>">
                                <?php echo e($c->type); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input
                            type="submit"
                            value="Apply Filter"
                            class="btn-fluid btn-sm btn-primary form-control"
                        />
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-8 offset-1">
            <div id="alert"></div>
            <div class="recent-item mt-5">
                <div class="row ind">
                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 px-3 py-3 cover">
                        <div class="card">
                            <div class="img">
                                <a href="<?php echo e(url('/item/'.$i->slug)); ?>">
                                    <img
                                        class="card-img-top bg-light"
                                        src="<?php echo e(asset($i->image)); ?>"
                                    />
                                </a>
                            </div>
                            <div class="card-body">
                                <div class="row mb-3">
                                    <div class="col-md-7">
                                        <small><?php echo e($i->name); ?></small>
                                    </div>
                                    <div class="col-md-5">
                                        <i class="text-primary"> New </i>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <p class="text-info"><?php echo e($i->price); ?></p>
                                    </div>
                                </div>
                                <div class="row px-1">
                                    <i class="bi bi-person-circle"
                                        >&nbsp;<?php echo e($i->ownername); ?></i
                                    >
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($item->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Web_Assignment/web_ass/resources/views/frontend/filter.blade.php ENDPATH**/ ?>