 <?php $__env->startSection('content'); ?>
<?php $__env->startSection('item-active','active'); ?>
<div class="container">
    <div class="d-flex">
        <a
            href="<?php echo e(route('items.index')); ?>"
            class="text-muted mb-0 hover-cursor"
        >
            &nbsp;Item List&nbsp; </a
        ><i class="bi bi-chevron-right"></i>&nbsp;
        <p class="text-primary mb-0 hover-cursor">Edit Items</p>
    </div>
    <div class="title mt-5 rounded">
        <h5 class="px-2 py-2">Edit Items</h5>
    </div>

    <form
        action="<?php echo e(route('items.update',$item->id)); ?>"
        method="post"
        class="mt-3"
        enctype="multipart/form-data"
    >
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div style="float: left">
            <b>Item Information</b>
            <div class="form-group mt-3">
                <p>Item Name</p>
                <input
                    type="text"
                    name="name"
                    id=""
                    class="form-control"
                    value="<?php echo e($item->name); ?>"
                />
            </div>
            <div class="form-group">
                <p>Select Category</p>
                <select name="category_id" id="" class="form-control mt-1">
                    <?php $__currentLoopData = $cat_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <p>Enter Price</p>
                <input
                    type="number"
                    name="price"
                    class="form-control"
                    value="<?php echo e($item->price); ?>"
                />
            </div>
            <div class="form-group">
                <p>Enter Description</p>
                <textarea
                    name="description"
                    id="description"
                    cols="20"
                    rows="3"
                    ><?php echo e($item->description); ?></textarea
                >
                <script>
                    CKEDITOR.replace("description");
                </script>
            </div>
            <div class="form-group">
                <p>Select Item Condition</p>
                <select name="condition_id" id="" class="form-control mt-1">
                    <?php $__currentLoopData = $item_con; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>">
                        <?php echo e($c->condition); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <p>Select Item Type</p>
                <select name="type_id" id="" class="form-control mt-1">
                    <?php $__currentLoopData = $item_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>">
                        <?php echo e($c->type); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for=""
                    >Status<br />
                    <input
                        type="checkbox"
                        id="status"
                        name="status"
                        value="public"
                        class="mt-2"
                    />
                    <b>Public</b>
                </label>
            </div>
            <div class="form-group">
                <label for="">Choose Image</label>
                <input type="file" name="image" class="form-control" />
                <img
                    src="<?php echo e(asset($item->image)); ?>"
                    alt=""
                    style="width: 20%"
                    class="mt-3"
                    rounded
                />
            </div>
        </div>

        <div style="float: right">
            <b>Owner Information</b>
            <div class="form-group mt-3">
                <p>Owner Name</p>
                <input
                    type="text"
                    name="ownername"
                    id=""
                    class="form-control"
                    value="<?php echo e($item->ownername); ?>"
                />
            </div>
            <div class="form-group">
                <p>Contact number:</p>
                <input
                    id="phone"
                    type="tel"
                    name="phone"
                    class="form-control"
                    value="<?php echo e($item->phone); ?>"
                />
            </div>
            <div class="form-group">
                <p>Address</p>
                <textarea
                    name="address"
                    class="form-control"
                    id=""
                    cols="30"
                    rows="3"
                    ><?php echo e($item->address); ?></textarea
                >
            </div>
            <div class="form-group">
                <a
                    href="<?php echo e(route('items.index')); ?>"
                    class="btn btn-sm btn-light mt-3 ml-3"
                    >Cancel</a
                >
                <input
                    type="submit"
                    value="Update"
                    class="btn btn-sm save mt-3 ml-3"
                />
            </div>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?> <?php $__env->startSection('script'); ?>
<script>
    const phoneInputField = document.querySelector("#phone");
    const phoneInput = window.intlTelInput(phoneInputField, {
        utilsScript:
            "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Web_Assignment/web_ass/resources/views/backend/edititem.blade.php ENDPATH**/ ?>