 <?php $__env->startSection('content'); ?>
<div class="container">
    <div class="header">
        <img src="/images/os1.jpg" alt="" />
        <div class="search mb-5">
            <form
                action="<?php echo e(url('/search')); ?>"
                method="get"
                class="form-inline"
            >
            <div class=" search-cat d-flex ">
                  <i class="bi bi-search ml-2 py-2"></i><input
                    class="form-control mr-sm-2 border-0"
                    type="search"
                    name="search"
                    placeholder="Search Item"
                    aria-label="Search"
                />
                <span class="left-pan ">    <a
                                            class="nav-link dropdown-toggle text-dark"
                                            href="#"
                                            id="navbarDropdown"
                                            role="button"
                                            data-toggle="dropdown"
                                            aria-haspopup="true"
                                            aria-expanded="false"
                                        >
                                            Category
                                        </a>
                                        <div
                                            class="dropdown-menu"
                                            aria-labelledby="navbarDropdown"
                                        >
                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a
                                                class="dropdown-item"
                                                href="<?php echo e(url('/item/category/'.$c->slug)); ?>"
                                                ><?php echo e($c->name); ?></a
                                            >

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
            </div>
                <button class="btn btn-sm btn-primary" type="submit">
                    Search
                </button></span>
            
            </form>
        </div>
    </div>
    <div class="main">
        <div class="info mt-5">
            <div class="row">
                <div class="col-md-9">
                    <h4>What are you looking for?</h4>
                </div>
                <div class="col-md-3" >
                    <a href="#"> View more <i class="bi bi-chevron-right"></i> </a>
                </div>
            </div>
            <div class="row d-flex mt-3 px-3 py-2">
                <div class="bg-light px-4 py-2">
                    <a href="<?php echo e(url('/fashion')); ?>" 
                        ><h2 class="ml-2 icon"><i class="bi bi-laptop"></i></h2
                    ></a>
                  <small>Computer</small>
                </div>
                &nbsp;&nbsp;&nbsp;
                <div class="bg-light px-2 py-2">
                    <a href="<?php echo e(url('/fashion')); ?>" 
                        ><h2 class="ml-1 icon"><i class="bi bi-phone"></i></h2
                    ></a>
                    <small>Phone</small>
                </div>
                &nbsp;&nbsp;&nbsp;
                <div class="bg-light px-2 py-2">
                    <a href="<?php echo e(url('/fashion')); ?>" 
                        ><h2 class="ml-2 icon"><i class="bi bi-house-door"></i></h2
                    ></a>
                    <small>Property</small>
                </div>
                &nbsp;&nbsp;&nbsp;
                <div class="bg-light px-2 py-2">
                    <a href="<?php echo e(url('/fashion')); ?>" 
                        ><h2 class="ml-1 icon"><i class="bi bi-music-note-beamed"></i></h2
                    ></a>
                    <small>Music</small>
                    </div>
                    &nbsp;&nbsp;&nbsp;
                    <div class="bg-light px-2 py-2">
                        <a href="<?php echo e(url('/fashion')); ?>" 
                            ><h2 class="ml-1 icon"><i class='fas fa-tshirt'></i></h2
                        ></a>
                        <small>Fashion</small>
                    </div>
                    &nbsp;&nbsp;&nbsp;
                    <div class="bg-light px-2 py-2">
                        <a href="<?php echo e(url('/fashion')); ?>" 
                            ><h2 class="ml-1 icon"><i class="bi bi-tools"></i></h2
                        ></a>
                        <small>Service</small>
                    </div>
                </div>
            </div>

            <div id="alert"></div>
            
            <div class="recent-item mt-5">
                <div class="row">
                <div class="col-md-9">
                    <h4>Recent Items</h4>
                </div>
                <div class="col-md-3" >
                    <a href="#"> View more <i class="bi bi-chevron-right"></i> </a>
                </div>
            </div>
                <div class="row ind">
                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 px-3 py-3 cover">
                        <div class="card ">
                            <div class="img">
                              <a href="<?php echo e(url('/item/'.$i->slug)); ?>" >
                                <img
                                    class="card-img-top bg-light"
                                    src="<?php echo e(asset($i->image)); ?>"
                                    
                                />
                            </a>
                            </div>
                            <div class="card-body item-bg">
                                <div class="row mb-3">
                                    <div class="col-md-7">
                                        <small><?php echo e($i->name); ?></small>
                                    </div>
                                    <div class="col-md-5">
                                        <i class="text-primary"><?php echo e($i->price); ?></i>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        
                                            <?php $__currentLoopData = $i->condition; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p class="text-primary">
                                                <?php echo e($con->condition); ?>

                                            </p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                      
                                    </div>
                                </div>
                                <div class="row mt-1 px-1">
                                    <i class="bi bi-person-circle">&nbsp;<?php echo e($i->ownername); ?></i
                                    >
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <!-- <div class="row mt-3">
        <div class="col-md-12">
            <?php echo e($item->links()); ?>

        </div>
    </div> -->
    </div>
    <?php $__env->stopSection(); ?>
</div>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Web_Assignment/web_ass/resources/views/frontend/home.blade.php ENDPATH**/ ?>