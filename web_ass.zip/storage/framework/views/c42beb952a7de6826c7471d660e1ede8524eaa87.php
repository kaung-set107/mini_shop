 <?php $__env->startSection('content'); ?>
<?php $__env->startSection('item-active','active'); ?>
<h2>Item</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Web_Assignment/web_ass/resources/views/backend/home.blade.php ENDPATH**/ ?>